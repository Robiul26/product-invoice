<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-md-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h5 class="card-title">Card title</h5>
                        <a href="{{ route('product.create') }}" class="btn btn-primary btn-sm">Add new Product</a>
                    </div>
                    <div class="card-body">
                        @if (session()->has('success'))
                            <div class="alert alert-success">
                                {{ session()->get('success') }}
                            </div>
                        @endif
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Product Name</th>
                                    <th scope="col">Uit</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($products as $product)
                                    <tr>
                                        <th scope="row">{{ $loop->iteration }}</th>
                                        <td>{{ $product->name }}</td>
                                        <td>{{ $product->unit }}</td>
                                        <td>View</td>
                                    </tr>
                                @endforeach

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="row justify-content-md-center mt-5">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h5 class="card-title">Invoice</h5>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('product.store') }}" method="POST">
                            @csrf

                            <div class="card mb-2">
                                <div class="card-body">
                                    <div class="mb-3 d-flex justify-content-between">
                                        <select class="form-control" name="unit" id="unit"
                                            placeholder="Product Unit">
                                            <option value="">Select Product</option>
                                            @foreach ($products as $produt)
                                                <option value="{{ $produt->name }}">{{ $produt->name }}</option>
                                            @endforeach

                                        </select>
                                        <div class="">
                                            <button class="btn btn-primary btn-sm">+ Add More</button>
                                          </div>
                                    </div>
                                    <table class="table" id="variant-table">
                                        <thead>
                                            <tr>
                                                <th scope="col">Produt Name</th>
                                                <th scope="col">description</th>
                                                <th scope="col">Price</th>
                                                <th scope="col">QTY</th>
                                                <th scope="col">Sub Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="variant-row">
                                                <td>
                                                    <input type="text" name="product_name[]" class="form-control"
                                                        disabled>
                                                </td>
                                                <td>
                                                    <select class="form-control" name="product_description[]">

                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="text" name="quantity[]" class="form-control"
                                                        placeholder="Product quantity">
                                                </td>
                                                <td>
                                                    <input type="text" name="unit_price[]" class="form-control"
                                                        disabled>
                                                </td>
                                                <td>
                                                    <input type="text" name="total_price[]" class="form-control"
                                                        disabled>
                                                </td>
                                                <td><button class="btn btn-danger btn-sm remove-variant"
                                                        type="button">X</button></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">Submit</button>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
</body>

</html>
