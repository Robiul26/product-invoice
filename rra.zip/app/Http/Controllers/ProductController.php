<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\ProductUnit;
use App\Models\ProductVariant;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data['products'] = Product::latest()->get();
        return view('product.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $data['product_varients'] = ProductVariant::latest()->get();
        return view('product.create', $data);
    }

   
    public function store(Request $request)
    {
        // Validate the input
        $request->validate([
            'name' => 'required|max:255',
            'unit' => 'required',
            'price' => 'required|array',  // price must be an array
            'price.*' => 'required|numeric',  // each price must be numeric
            'description' => 'required|array',  // description must be an array
            'description.*' => 'required|string',  // each description must be a string
        ]);

        // Create a new product
        $product = new Product();
        $product->name = $request->name;
        $product->unit = $request->unit;

        // Save the product
        if ($product->save()) {
            // Loop through each price and description and create a variant for each
            foreach ($request->price as $index => $price) {
                $variant = new ProductVariant();
                $variant->product_id = $product->id;  // Associate the variant with the product
                $variant->price = $price;
                $variant->description = $request->description[$index];
                $variant->save();
            }
        }

        // Redirect to the product index with success message
        return redirect()->route('product.index')->with('success', 'Product was created');
    }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
